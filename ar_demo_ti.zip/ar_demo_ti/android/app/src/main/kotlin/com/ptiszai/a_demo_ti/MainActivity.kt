package com.ptiszai.ar_demo_ti

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
